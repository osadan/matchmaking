-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 12, 2011 at 01:17 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `shiduchim`
--

-- --------------------------------------------------------

--
-- Table structure for table `advocats`
--

CREATE TABLE `advocats` (
  `id` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL default '',
  `relate` varchar(50) default NULL,
  `phone` varchar(50) default NULL,
  `address` varchar(64) default NULL,
  `work` varchar(252) default NULL,
  `recommand` varchar(252) default NULL,
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `advocats`
--

INSERT INTO `advocats` (`id`, `pid`, `name`, `relate`, `phone`, `address`, `work`, `recommand`) VALUES
(1, 1, 'ירושלמי', 'חבר טוב', '026731136', 'ראובן 12', 'בחור ישיבה', 'בחור טוב'),
(2, 1, 'מלצר', 'יעקב', '0526731136', 'אפרתי 34', 'רבה בחדר', 'בחור מוצלח'),
(3, 16, 'כהן אושרית', 'חברה', '0546966332', 'אדם', 'מטפלת', ''),
(4, 16, 'סדן מיכל', 'אחות של חברה', '0527122335', 'יוסלה רוזנבלט רמות ג'' ירושלים', 'מזכירה רפואית', ''),
(5, 36, 'גוטליב', 'אח', '0775867863', 'מיץ 18', 'אברך', 'ממליץ ביותר');

-- --------------------------------------------------------

--
-- Table structure for table `defanitions`
--

CREATE TABLE `defanitions` (
  `id` int(11) NOT NULL auto_increment,
  `item_id` int(11) default NULL,
  `name` varchar(128) default NULL,
  `status` enum('active','disables') default 'active',
  `remarks` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `defanitions`
--

INSERT INTO `defanitions` (`id`, `item_id`, `name`, `status`, `remarks`) VALUES
(1, 2, 'חסידי', 'active', NULL),
(2, 3, 'ארוך', 'active', NULL),
(3, 6, 'ארוכות', 'active', NULL),
(4, 2, 'ליטאי', 'active', NULL),
(6, 2, 'חרד"ל', 'active', NULL),
(5, 2, 'ספרדי', 'active', NULL),
(28, 6, 'קצרות', 'active', NULL),
(7, 2, 'דתי לאומי', 'active', NULL),
(8, 2, 'חוזר בתשובה', 'active', NULL),
(9, 2, 'אחר', 'active', NULL),
(10, 3, 'קצר', 'active', NULL),
(11, 3, 'מגולח', 'active', NULL),
(12, 3, 'מסודר', 'active', NULL),
(13, 3, 'שפם', 'active', NULL),
(14, 3, 'ללא ', 'active', NULL),
(15, 3, 'אחר', 'active', NULL),
(16, 4, 'ארוכה', 'active', NULL),
(17, 4, 'קצרה', 'active', NULL),
(18, 4, 'חאלט', 'active', NULL),
(19, 4, 'ירושלמי', 'active', NULL),
(20, 4, 'ללא', 'active', NULL),
(21, 4, 'אחר', 'active', NULL),
(22, 7, 'חסידי', 'active', NULL),
(23, 7, 'ירושלמי', 'active', NULL),
(25, 7, 'קנייץ''', 'active', NULL),
(26, 7, 'ללא', 'active', NULL),
(27, 7, 'אחר', 'active', NULL),
(29, 6, 'מסולסלות', 'active', NULL),
(30, 6, 'אחרי האוזן', 'active', NULL),
(31, 6, 'ללא', 'active', NULL),
(32, 6, 'אחר', 'active', NULL),
(33, 8, 'פאה נוכרית', 'active', NULL),
(34, 8, 'מטפחת', 'active', NULL),
(35, 8, 'כובע', 'active', NULL),
(36, 8, 'אחר', 'active', NULL),
(37, 9, 'שמרנית ', 'active', NULL),
(38, 9, 'מודרנית', 'active', NULL),
(39, 9, 'רגילה', 'active', NULL),
(40, 9, 'יוקרתית', 'active', NULL),
(41, 9, 'אחר', 'active', NULL),
(42, 21, 'הוצע מועמד', 'active', NULL),
(43, 21, 'מחכה לתגובה ראשונית', 'active', NULL),
(44, 21, 'תגובה ראשונית מהוססת', 'active', NULL),
(45, 21, 'תגובה ראשונית חיובית', 'active', NULL),
(46, 21, 'להתקשר להציע מועמד', 'active', NULL),
(47, 21, 'ממתין לתשובה', 'active', NULL),
(48, 21, 'רוצה להמשיך', 'active', NULL),
(49, 21, 'עובר לפגישה', 'active', NULL),
(50, 22, 'צריך לחשוב', 'active', NULL),
(51, 22, 'רוצה להמשיך', 'active', NULL),
(52, 22, 'לקראת סגירה', 'active', NULL),
(53, 22, 'צריך להתקשר', 'active', NULL),
(54, 22, 'לקראת פגישה ראשונה', 'active', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `extrnalview`
--

CREATE TABLE `extrnalview` (
  `id` int(11) NOT NULL auto_increment,
  `p_id` int(11) NOT NULL,
  `bird` varchar(52) default NULL,
  `hat` varchar(52) default NULL,
  `suit` varchar(52) default NULL,
  `sideburns` varchar(52) default NULL,
  `height` varchar(128) default NULL,
  `fabric` varchar(128) default NULL,
  `generalLook` mediumtext,
  `outLook` varchar(45) default NULL,
  `wigg` varchar(45) default NULL,
  `glasses` tinyint(1) unsigned default '0',
  PRIMARY KEY  (`id`,`p_id`),
  UNIQUE KEY `p_id` (`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `extrnalview`
--

INSERT INTO `extrnalview` (`id`, `p_id`, `bird`, `hat`, `suit`, `sideburns`, `height`, `fabric`, `generalLook`, `outLook`, `wigg`, `glasses`) VALUES
(1, 1, 'short', 'kneych', 'long', 'afterEar', 'גבוה', 'רגיל', 'נחמד מאוד', '', '', 0),
(2, 4, '12', '25', '17', '29', '', '', '', '', '', 0),
(3, 9, '2', '23', '18', '3', '', '', '', '', '', 0),
(4, 10, '', '', '', '', '', '', '', '', '33', 0),
(5, 11, '2', '22', '16', '28', '', '', '', '', '', 0),
(6, 12, '', '', '', '', '', '', '', '37', '', 0),
(7, 13, '2', '26', '20', '28', 'גבוה', 'רזה', '', '', '', 1),
(8, 14, '2', '23', '18', '28', '', '', '', '', '', 0),
(9, 15, '', '', '', '', '', '', '', '38', '33', 1),
(10, 16, '', '', '', '', 'נורמלי', 'קצת ..', '', '38', '36', 1),
(11, 17, '14', '25', '17', '28', '', '', '', '', '', 0),
(12, 20, '', '', '', '', '', '', '', '39', '', 0),
(13, 8, '', '', '', '', '', '', '', '', '34', 0),
(14, 2, '', '', '', '', '', '', '', '', '', 1),
(15, 36, '2', '23', '19', '3', '180', 'רזה', 'בחור נחמד', '39', '', 1),
(16, 41, '2', '22', '16', '3', '', '', '', '39', '', 0),
(17, 42, '10', '26', '20', '31', '', '', '', '39', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `institutions`
--

CREATE TABLE `institutions` (
  `id` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `y_from` varchar(50) default NULL,
  `y_to` varchar(50) default NULL,
  `comment` varchar(252) default NULL,
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `institutions`
--

INSERT INTO `institutions` (`id`, `pid`, `name`, `y_from`, `y_to`, `comment`) VALUES
(1, 1, 'שערי משפט', '2010', '2010', ''),
(2, 16, 'מכללת הדסה', '2007', '2009', ''),
(3, 16, 'צביה', '1998', '2001', ''),
(4, 36, 'ישיבת תפארת ישראל', '2004', '2008', 'בחור מצויין'),
(5, 41, 'אור ירושלים', 'תשס"ד', '', 'תלמיד מצטיין');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) default NULL,
  `status` enum('active','disabled') default 'active',
  `type` tinyint(1) default NULL,
  `var` varchar(128) default NULL,
  `gender` enum('male','female','both') default 'both',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `status`, `type`, `var`, `gender`) VALUES
(7, 'כובע', 'active', NULL, 'hats', 'male'),
(2, 'זרם', 'active', NULL, 'flows', 'both'),
(3, 'זקן', 'active', NULL, 'birds', 'male'),
(4, 'חליפה', 'active', NULL, 'suits', 'male'),
(8, 'כיסוי ראש', 'active', NULL, 'wiggs', 'female'),
(6, 'פאות', 'active', NULL, 'sideburns', 'male'),
(9, 'הופעה', 'active', NULL, 'outLooks', 'both'),
(21, 'סטטוס הצעה', 'active', NULL, 'offer_process_status', 'both'),
(20, 'סטטוס בן ', 'active', NULL, 'male_status_offers', 'male'),
(22, 'סטטוס פגישה', 'active', NULL, 'meeting_status', 'both');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(10) unsigned NOT NULL,
  `random` varchar(256) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `l_date` bigint(20) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `userid`, `random`, `ip`, `l_date`) VALUES
(29, 4, '631c409473b0f6071aca82e091a80fc3', '127.0.0.1', 20110907014355),
(19, 3, '283bf96c3111339c28ec04e78dbe6c90', '127.0.0.1', 20110513002956),
(45, 2, '349de91ef947e095c64b425a3cdb4717', '127.0.0.1', 20110912011124),
(46, 1, 'a3f9b7a068ee1477ea830879a22cddca', '127.0.0.1', 20110912011326);

-- --------------------------------------------------------

--
-- Table structure for table `meetings`
--

CREATE TABLE `meetings` (
  `m_id` int(11) NOT NULL auto_increment,
  `offer_id` int(11) default NULL,
  `meeting_date` varchar(256) NOT NULL,
  `meeting_place` varchar(128) default NULL,
  `status` int(10) unsigned default NULL,
  `remarks` text,
  `meeting_created` datetime NOT NULL,
  `meeting_updated` datetime NOT NULL,
  PRIMARY KEY  USING BTREE (`m_id`),
  KEY `offer_id` (`offer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `meetings`
--

INSERT INTO `meetings` (`m_id`, `offer_id`, `meeting_date`, `meeting_place`, `status`, `remarks`, `meeting_created`, `meeting_updated`) VALUES
(21, 15, 'a:4:{s:4:"time";s:5:"20:00";s:4:"days";s:1:"1";s:5:"month";s:1:"1";s:5:"years";s:4:"2012";}', 'ניסיון נוסך', NULL, 'ניסיון נוסף', '2011-09-04 16:45:02', '2011-09-04 16:45:02'),
(12, 15, 'a:4:{s:4:"time";s:5:"20:30";s:4:"days";s:1:"7";s:5:"month";s:1:"6";s:5:"years";s:4:"2011";}', 'ירושלים בית הכרם שינוי1', NULL, 'אולי ייפגשו בראשון לציון לא לשכוח להוסיף שינויי פגישות בהיסטוריה 111', '2011-09-04 02:48:22', '2011-09-04 16:29:51'),
(11, 15, 'a:4:{s:4:"time";s:5:"21:30";s:4:"days";s:1:"5";s:5:"month";s:1:"6";s:5:"years";s:4:"2011";}', 'בית השיטה', NULL, 'אולי ייפגשו בראשון לציון לא לשכוח להוסיף שינויי פגישות בהיסטוריה', '2011-09-04 02:47:14', '2011-09-04 02:47:14'),
(7, 15, 'a:4:{s:4:"time";s:5:"18:30";s:4:"days";s:1:"3";s:5:"month";s:1:"6";s:5:"years";s:4:"2011";}', 'בני ברק חומה ומגדל 3', NULL, 'כמה הערות כאן שונות ומשונות עוד הערה', '2011-09-02 03:17:32', '2011-09-04 02:43:52'),
(25, 15, 'a:4:{s:4:"time";s:5:"21:00";s:4:"days";s:1:"9";s:5:"month";s:1:"6";s:5:"years";s:4:"2011";}', 'הר נוף', NULL, 'הר נוף רחוב משקלוב 5 שם חבר שלי שקוראים לו בבתי ', '2011-09-04 18:26:02', '2011-09-04 18:27:02'),
(14, 15, 'a:4:{s:4:"time";s:5:"21:30";s:4:"days";s:1:"7";s:5:"month";s:1:"6";s:5:"years";s:4:"2011";}', 'ירושלים בית הכרם ', NULL, 'אולי ייפגשו בראשון לציון לא לשכוח להוסיף שינויי פגישות בהיסטוריה  ששa', '2011-09-04 02:50:14', '2011-09-04 16:10:21'),
(18, 15, 'a:4:{s:4:"time";s:5:"19:30";s:4:"days";s:1:"9";s:5:"month";s:1:"6";s:5:"years";s:4:"2012";}', 'זכרון יעקב', NULL, 'בשאיפה פגישה אחרונה', '2011-09-04 16:32:51', '2011-09-04 16:32:51'),
(19, 15, 'a:4:{s:4:"time";s:5:"21:30";s:4:"days";s:1:"1";s:5:"month";s:1:"7";s:5:"years";s:4:"2012";}', 'רחובות ', NULL, 'וורט ', '2011-09-04 16:37:45', '2011-09-04 16:37:45'),
(20, 16, 'a:4:{s:4:"time";s:5:"18:30";s:4:"days";s:1:"9";s:5:"month";s:1:"6";s:5:"years";s:4:"2011";}', 'ירושלים', NULL, 'הר נוף איפה שגר אושר בבתי ', '2011-09-04 16:43:01', '2011-09-05 19:28:31'),
(22, 15, 'a:4:{s:4:"time";s:4:"8:00";s:4:"days";s:1:"3";s:5:"month";s:1:"1";s:5:"years";s:4:"2012";}', 'vbg', NULL, 'fsdsdf', '2011-09-04 16:47:02', '2011-09-04 16:47:02'),
(23, 15, 'a:4:{s:4:"time";s:5:"20:00";s:4:"days";s:1:"1";s:5:"month";s:1:"1";s:5:"years";s:4:"2012";}', 'בית מלון', NULL, 'כמה הם יכולים להפגש 2', '2011-09-04 16:49:04', '2011-09-04 16:49:14'),
(24, 15, 'a:4:{s:4:"time";s:5:"22:00";s:4:"days";s:1:"6";s:5:"month";s:1:"6";s:5:"years";s:4:"2011";}', 'רמות ג', NULL, 'להביא מים', '2011-09-04 18:18:13', '2011-09-04 18:18:51'),
(26, 15, 'a:4:{s:4:"time";s:5:"20:00";s:4:"days";s:1:"1";s:5:"month";s:1:"1";s:5:"years";s:4:"2012";}', 'ירושלים', NULL, '', '2011-09-04 21:06:03', '2011-09-04 21:06:03'),
(27, 16, 'a:4:{s:4:"time";s:5:"18:30";s:4:"days";s:1:"9";s:5:"month";s:1:"6";s:5:"years";s:4:"2011";}', 'ירושלים', NULL, 'הר נוף איפה שגר בבתי ', '2011-09-05 19:28:05', '2011-09-05 19:28:05'),
(28, 17, 'a:4:{s:4:"time";s:5:"20:00";s:4:"days";s:1:"1";s:5:"month";s:1:"7";s:5:"years";s:4:"2012";}', 'בני ברק ', NULL, '', '2011-09-06 02:36:04', '2011-09-06 02:36:04');

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `o_id` int(11) NOT NULL auto_increment,
  `boy_id` int(11) default NULL,
  `girl_id` int(11) default NULL,
  `status` enum('offer','meeting','refused','MazalTov') default 'offer',
  `update_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `insert_date` timestamp NOT NULL default '0000-00-00 00:00:00',
  `weight` int(10) unsigned NOT NULL default '0',
  `status_boy` int(10) unsigned default NULL,
  `status_girl` int(10) unsigned default NULL,
  PRIMARY KEY  USING BTREE (`o_id`),
  UNIQUE KEY `uniqe_boy_girl` USING BTREE (`boy_id`,`girl_id`),
  KEY `boy_id` (`boy_id`),
  KEY `girl_id` (`girl_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=18 ;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`o_id`, `boy_id`, `girl_id`, `status`, `update_date`, `insert_date`, `weight`, `status_boy`, `status_girl`) VALUES
(6, 19, 16, 'offer', '2011-08-31 00:55:05', '0000-00-00 00:00:00', 0, 45, 46),
(7, 17, 16, 'offer', '2011-08-31 01:52:00', '2011-08-22 23:59:04', 0, 44, 0),
(8, 19, 15, 'offer', '2011-09-05 19:23:58', '2011-08-23 00:27:12', 0, 42, 43),
(9, 19, 6, 'refused', '2011-09-05 19:25:15', '2011-08-23 00:27:32', 0, 0, 0),
(13, 17, 12, 'offer', '2011-08-24 19:27:18', '2011-08-24 19:27:18', 0, NULL, NULL),
(15, 9, 16, 'MazalTov', '2011-09-04 21:09:19', '2011-08-24 23:15:39', 0, 0, 0),
(16, 19, 18, 'meeting', '2011-09-05 19:27:37', '2011-09-05 19:25:51', 0, 50, 52),
(17, 19, 38, 'meeting', '2011-09-06 02:36:18', '2011-09-06 02:34:50', 0, 54, 54);

-- --------------------------------------------------------

--
-- Table structure for table `offers_remarks`
--

CREATE TABLE `offers_remarks` (
  `r_id` int(10) unsigned NOT NULL auto_increment,
  `offer_id` int(10) unsigned NOT NULL,
  `insert_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL default '0000-00-00 00:00:00',
  `text` text,
  PRIMARY KEY  (`r_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `offers_remarks`
--

INSERT INTO `offers_remarks` (`r_id`, `offer_id`, `insert_date`, `update_date`, `text`) VALUES
(1, 6, '2011-08-30 23:49:05', '2011-08-30 23:49:05', 'תגובה ראשונית חיובית משני הצדדים'),
(2, 6, '2011-08-30 23:54:17', '2011-08-30 23:54:17', 'תגובה ראשונית חיובית משני הצדדים'),
(3, 6, '2011-08-31 00:55:05', '2011-08-31 00:55:05', 'צריך ללחוץ קצת יותר'),
(4, 6, '2011-08-31 00:58:36', '2011-08-31 00:58:36', 'צריך ללחוץ קצת יותר'),
(5, 15, '2011-08-31 01:32:13', '2011-08-31 01:32:13', 'השתנה ססטוס בן מ - ל - הוצע מועמד<br />השתנה ססטוס בתל - מחכה לתגובה ראשונית<br /><br />מחכה לתגובות ראשוניות משני הצדדים'),
(6, 7, '2011-08-31 01:50:24', '2011-08-31 01:50:24', 'השתנה ססטוס בן מ - ל - מחכה לתגובה ראשונית<br />השתנה ססטוס בת מ - ל - בחר<br />הערות<br />מחכה לתגובה ראשונית מהמועמד'),
(7, 7, '2011-08-31 01:52:00', '2011-08-31 01:52:00', 'השתנה ססטוס בן מ - מחכה לתגובה ראשוניתל - תגובה ראשונית מהוססת<br />'),
(8, 15, '2011-08-31 23:00:32', '2011-08-31 23:00:32', 'השתנה סטטוס הצעה מ - הצעהל - <br />השתנה ססטוס בן מ - הוצע מועמד ל - תגובה ראשונית חיובית<br />השתנה ססטוס בת מ - מחכה לתגובה ראשונית ל - תגובה ראשונית חיובית<br />הערות<br />החברה נפגשים'),
(9, 15, '2011-08-31 23:03:06', '2011-08-31 23:03:06', 'החברה נפגשים'),
(10, 15, '2011-09-01 21:41:53', '2011-09-01 21:41:53', 'השתנה ססטוס בן מ - תגובה ראשונית חיובית ל - בחר<br />השתנה ססטוס בת מ - תגובה ראשונית חיובית ל - בחר<br />'),
(11, 15, '2011-09-01 22:25:55', '2011-09-01 22:25:55', 'השתנה ססטוס בן מ - בחר ל - <br />השתנה ססטוס בת מ - בחר ל - <br />'),
(12, 15, '2011-09-01 22:41:25', '2011-09-01 22:41:25', 'השתנה ססטוס בן מ - לקראת פגישה ראשונה ל - צריך לחשוב<br />השתנה ססטוס בת מ - צריך להתקשר ל - לקראת פגישה ראשונה<br />'),
(13, 15, '2011-09-04 21:06:03', '2011-09-04 21:06:03', 'הוכנסה פגישה חדשה <br /> מיקום:ירושלים<br />זמן: א'' ניסן התשעב-20:00'),
(14, 15, '2011-09-04 21:09:19', '2011-09-04 21:09:19', 'השתנה סטטוס הצעה מ - בפגישותל - <br />'),
(15, 8, '2011-09-05 19:23:58', '2011-09-05 19:23:58', 'השתנה ססטוס בן מ -  ל - הוצע מועמד<br />השתנה ססטוס בת מ -  ל - מחכה לתגובה ראשונית<br />'),
(16, 8, '2011-09-05 19:24:13', '2011-09-05 19:24:13', 'כמה הערות מגוונות'),
(17, 9, '2011-09-05 19:25:15', '2011-09-05 19:25:15', 'השתנה סטטוס הצעה מ - הצעהל - נדחה<br />'),
(18, 16, '2011-09-05 19:27:11', '2011-09-05 19:27:11', 'השתנה סטטוס הצעה מ - הצעהל - בפגישות<br />'),
(19, 16, '2011-09-05 19:27:37', '2011-09-05 19:27:37', 'השתנה ססטוס בן מ - בחר ל - צריך לחשוב<br />השתנה ססטוס בת מ - בחר ל - לקראת סגירה<br />'),
(20, 16, '2011-09-05 19:28:05', '2011-09-05 19:28:05', 'הוכנסה פגישה חדשה <br /> מיקום:ירושלים<br />זמן: ט'' אלול התשעא-18:30'),
(21, 16, '2011-09-05 19:28:31', '2011-09-05 19:28:31', 'עודכנה פגישה<br /> מיקום:ירושלים<br />זמן: ט'' אלול התשעא-18:30'),
(22, 17, '2011-09-06 02:35:12', '2011-09-06 02:35:12', 'השתנה ססטוס בן מ - בחר ל - הוצע מועמד<br />השתנה ססטוס בת מ - בחר ל - הוצע מועמד<br />'),
(23, 17, '2011-09-06 02:35:31', '2011-09-06 02:35:31', 'השתנה ססטוס בן מ - הוצע מועמד ל - עובר לפגישה<br />השתנה ססטוס בת מ - הוצע מועמד ל - עובר לפגישה<br />'),
(24, 17, '2011-09-06 02:35:41', '2011-09-06 02:35:41', 'השתנה סטטוס הצעה מ - הצעהל - בפגישות<br />'),
(25, 17, '2011-09-06 02:36:04', '2011-09-06 02:36:04', 'הוכנסה פגישה חדשה <br /> מיקום:בני ברק <br />זמן: א'' תשרי התשעב-20:00'),
(26, 17, '2011-09-06 02:36:18', '2011-09-06 02:36:18', 'השתנה ססטוס בן מ - בחר ל - לקראת פגישה ראשונה<br />השתנה ססטוס בת מ - בחר ל - לקראת פגישה ראשונה<br />');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `id` int(11) NOT NULL auto_increment,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `tid` int(11) default NULL,
  `gender` varchar(22) NOT NULL default '',
  `age` varchar(22) default NULL,
  `birthdate` varchar(9) character set latin1 collate latin1_general_ci default NULL,
  `dorYesharim` varchar(50) default NULL,
  `fatherName` varchar(50) default NULL,
  `fatherJob` varchar(50) default NULL,
  `fatherWork` varchar(50) default NULL,
  `motherName` varchar(50) default NULL,
  `motherLastName` varchar(50) default NULL,
  `motherJob` varchar(50) default NULL,
  `sibiling` varchar(22) default NULL,
  `flow` varchar(22) default NULL,
  `origin` varchar(50) default NULL,
  `street` varchar(50) default NULL,
  `neighborhood` varchar(50) default NULL,
  `city` varchar(50) default NULL,
  `country` varchar(50) default NULL,
  `phone` varchar(50) default NULL,
  `cellPhone` varchar(50) default NULL,
  `email` varchar(50) default NULL,
  `insertDate` datetime NOT NULL,
  `updateDate` datetime NOT NULL,
  `accupation` varchar(128) default NULL,
  `s_married` int(10) unsigned default NULL,
  `comments` mediumtext,
  `active` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `tid` (`tid`),
  FULLTEXT KEY `firstName` (`firstName`,`lastName`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`id`, `firstName`, `lastName`, `tid`, `gender`, `age`, `birthdate`, `dorYesharim`, `fatherName`, `fatherJob`, `fatherWork`, `motherName`, `motherLastName`, `motherJob`, `sibiling`, `flow`, `origin`, `street`, `neighborhood`, `city`, `country`, `phone`, `cellPhone`, `email`, `insertDate`, `updateDate`, `accupation`, `s_married`, `comments`, `active`) VALUES
(1, 'אהד', 'סדן-שטוק', 31485493, 'male', '1978', '19790704', '457867897654', 'אהוד', 'שוטר', 'משטרה', 'רחל', 'רחמים', 'עקרת בית', '3', '', 'יד עזרה', 'יוסלה רוזנבלט', 'רמות ג', 'ירושלים', 'ישראל', '026731136', '0527122336', 'sadanoh@gmail.com', '2010-10-27 00:00:00', '2011-08-25 00:00:00', 'מתכנת', 2, 'בחור נחמד', 1),
(2, 'אהד', 'סדן - שטוק', 0, 'male', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2011-01-18 00:00:00', '2011-01-18 00:00:00', '', 0, '', 1),
(3, 'אברהמי', 'ברוך', 3565656, 'male', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2011-01-18 00:00:00', '2011-08-25 00:00:00', '', 0, '', 1),
(4, 'סדן', 'אהד', 31485493, 'male', '1977', '19790704', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '2011-04-29 00:00:00', '2011-08-25 00:00:00', 'מתכנת', 0, 'לא כדאי להתחתן איתו', 1),
(5, 'דבורה', 'שטוק', 0, 'female', '1977', '20041101', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '2011-04-29 00:00:00', '2011-08-25 00:00:00', 'מנהלת לשכה', 0, '', 1),
(6, 'דבורה', 'שטוק', 0, 'female', '1993', '20041101', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '026731136', '', '', '2011-04-29 00:00:00', '2011-09-05 00:00:00', 'מנהלת לשכה', 0, '', 1),
(7, 'שירה', 'שטוק', 0, 'female', '1977', '19940401', '', '', '', '', '', '', '', '4', '1', 'גור', '', '', '', '', '', '', '', '2011-04-29 00:00:00', '2011-08-25 00:00:00', 'תלמידת גן', 1, '', 1),
(8, 'אלישבע', 'שטוק', 0, 'female', '1977', '19900000', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '', '', '', '2011-04-29 00:00:00', '2011-08-25 00:00:00', '', 0, '', 1),
(9, 'שרביט', 'יוסי', 0, 'male', '1977', '19900000', '', '', '', '', '', '', '', '', '4', '', '', 'רמות', '', '', '', '', '', '2011-05-01 00:00:00', '2011-08-25 00:00:00', '', 0, '', 0),
(10, 'בוסקילה1', 'שמעון', 0, 'female', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2011-05-01 00:00:00', '2011-08-25 00:00:00', '', 0, '', 1),
(11, 'מזרחי', 'יהושע', 0, 'male', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0569565989', '', '', '2011-05-01 00:00:00', '2011-09-06 00:00:00', '', 0, '', 1),
(12, 'לוי', 'שרה', 0, 'female', '1977', '19900000', '4645', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2011-05-01 00:00:00', '2011-08-25 00:00:00', '', 0, '', 1),
(13, 'משולם זושא', 'מוצאפי', 31485493, 'male', '1977', '19870302', '65998989', 'יוסף', '', '', 'רוחמה', 'מזרחי', 'עקרת בית', '4', '8', 'עיראקי', '', 'מבשרת ציון', 'ירושלים', 'ישראל', '026731136', '0527122336', '', '2011-05-11 00:00:00', '2011-09-05 00:00:00', 'מצחצח נעליים', 3, 'בחור מצויין', 1),
(14, 'ראובן', 'מועלם', 0, 'male', '1969', '19900000', '', '', '', '', '', '', '', '', '5', 'מרוקאי', '', '', '', '', '026731136', '0527122335', '', '2011-05-11 00:00:00', '2011-08-25 00:00:00', 'תלמיד ישיבה', 0, '', 1),
(15, 'שמחה', 'רבינוביץ', 3656565, 'female', '1993', '19900000', '665464', '', '', '', '', '', '', '', '4', 'ליטאית', '', '', '', '', '', '054698989', '', '2011-05-11 00:00:00', '2011-08-25 00:00:00', 'תלמידת סמינר', 0, '', 1),
(16, 'מיכל', 'כץ', 0, 'female', '1977', '19820000', '', 'משה', 'עורך דין', '', '', '', 'גננת', '5', '7', 'אשכנזיה', '', '', 'תל -אביב', 'ישראל', '', '', '', '2011-06-13 00:00:00', '2011-08-25 00:00:00', 'מעצבת פנים', 1, 'מחפשת בחור רציני מוכנה להתפשר', 0),
(17, 'משה', 'בנדר', 0, 'male', '1981', '19900000', '', '', '', '', '', '', '', '3', '4', 'אשכנזי', '', '', '', '', '', '', '', '2011-06-13 00:00:00', '2011-08-25 00:00:00', 'מתכנת', 0, '', 1),
(18, 'תהילה', 'גוזלאנד', 0, 'female', '1992', '19900000', '', 'יואל', 'סופר סתם', '', 'גלית', 'כהן', 'גננת', '3', '1', 'יד עזרה', '', 'בית צפאפאה', 'ירושלים', 'ישראל', '', '', '', '2011-06-13 00:00:00', '2011-08-25 00:00:00', 'נציגת שרות בחברת פלאפון', 1, '', 1),
(19, 'שמעון', 'רחמנוביץ', 0, 'male', '1977', '19900000', '', '', '', '', '', '', '', '', '1', '', '', '', '', '', '026731136', '', '', '2012-07-07 00:00:00', '2011-09-05 00:00:00', '', 0, '', 1),
(20, 'שמעון', 'בניסטי', 653263696, 'male', '1979', '19790604', '7787979', '', '', 'חברת ריל קומרס', 'גילה', '', 'פרופסור באוניברסיטה', '2', '', '', '', '', 'רמת גן', '', '026731136', '', '', '2011-08-25 00:00:00', '2011-08-25 00:00:00', 'מנהל פרוייקטים', 1, 'בחור נחמד ומוכשר , חילוני מוכן גם דתיה', 1),
(35, 'מעין', 'ששון', 6598656, 'female', '1979', '19790302', '7987854', 'ציון', 'שוטר (פנסיונר', 'משטרה', '', '', '', '1', '8', '', 'דב סדן', 'פסגת זאב', 'ירושלים', 'ישראל', '0267310326', '050656566', '', '2011-08-25 00:00:00', '2011-08-25 00:00:00', 'מנהלת פרוייקטים', 1, 'בחורה נחמדה מאד מחפשת בחור רציני ואחראי \r\nכדאי לנסות בכיוון של מתכנתים', 1),
(36, 'שמואל', 'ראובני', 0, 'male', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '026432656', '', '', '2011-09-04 00:00:00', '2011-09-04 00:00:00', '', 0, '', 1),
(37, 'ענת', 'וטורי', 44856546, 'female', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '06554545', '', '', '2011-09-04 00:00:00', '2011-09-04 00:00:00', '', 0, '', 1),
(38, 'תהילה', 'לונצר', 0, 'female', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '025860989', '', '', '2011-09-04 00:00:00', '2011-09-04 00:00:00', '', 0, '', 1),
(39, 'יעל', 'פרץ', 0, 'female', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0775002461', '', '', '2011-09-04 00:00:00', '2011-09-04 00:00:00', '', 0, '', 1),
(40, 'יעל', 'פרץ', 0, 'female', '1977', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0775002461', '', '', '2011-09-04 00:00:00', '2011-09-04 00:00:00', '', 0, '', 1),
(41, 'דן', 'שטוק', 536656265, 'male', '2004', '19900000', '', 'אהד', 'מתכנת', 'תל אביב', 'מיכל', 'כהן', '', '3', '', '', 'יוסלה רוזנבלט', 'רמות ג', 'ירושלים', 'ישראל', '026731136', '', '', '2011-09-05 00:00:00', '2011-09-05 00:00:00', 'תלמיד בחדר', 0, '', 1),
(42, 'מיטרני', 'רן', 75454542, 'male', '1980', '19900000', '', '', '', '', '', '', '', '2', '8', '', '', '', '', 'ישראל', '052798963', '', '', '2011-09-05 00:00:00', '2011-09-05 00:00:00', 'איש שיווק', 0, '', 1),
(43, 'רבקה', 'צ''ולפייב', 0, 'female', '1983', '19900000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '05267866', '', '', '2011-09-05 00:00:00', '2011-09-05 00:00:00', '', 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `person_defanitions`
--

CREATE TABLE `person_defanitions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `item_id` varchar(45) NOT NULL,
  `defanition_id` varchar(45) NOT NULL,
  `user_id` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uniq` (`user_id`,`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=108 ;

--
-- Dumping data for table `person_defanitions`
--

INSERT INTO `person_defanitions` (`id`, `item_id`, `defanition_id`, `user_id`) VALUES
(1, '2', '2', '8'),
(2, '2', '2', '9'),
(3, '2', '2', '10'),
(4, '2', '2', '11'),
(5, '2', '2', '12'),
(6, '9', '37', '12'),
(7, '8', '34', '12'),
(8, '3', '2', '11'),
(9, '7', '22', '11'),
(10, '4', '16', '11'),
(11, '6', '28', '11'),
(12, '3', '2', '9'),
(13, '7', '23', '9'),
(14, '4', '18', '9'),
(15, '6', '3', '9'),
(16, '2', '8', '13'),
(19, '2', '2', '14'),
(20, '2', '2', '15'),
(21, '8', '33', '15'),
(22, '9', '38', '15'),
(23, '3', '2', '14'),
(24, '7', '23', '14'),
(25, '4', '18', '14'),
(26, '6', '28', '14'),
(35, '3', '2', '13'),
(36, '7', '26', '13'),
(37, '4', '20', '13'),
(38, '6', '28', '13'),
(39, '2', '2', '16'),
(40, '8', '36', '16'),
(41, '9', '38', '16'),
(42, '2', '2', '17'),
(43, '3', '14', '17'),
(44, '7', '25', '17'),
(45, '4', '17', '17'),
(46, '6', '28', '17'),
(47, '2', '2', '18'),
(48, '2', '1', '19'),
(50, '2', '8', '22'),
(51, '2', '8', '23'),
(52, '2', '8', '24'),
(53, '2', '8', '25'),
(54, '2', '8', '26'),
(55, '2', '8', '27'),
(56, '2', '8', '28'),
(57, '2', '8', '29'),
(58, '2', '8', '30'),
(59, '2', '8', '31'),
(60, '2', '8', '32'),
(61, '2', '8', '33'),
(62, '2', '8', '34'),
(63, '2', '2', '35'),
(64, '9', '39', '20'),
(65, '2', '2', '1'),
(67, '2', '2', '20'),
(77, '8', '34', '8'),
(78, '2', '2', '7'),
(79, '2', '2', '5'),
(80, '2', '2', '4'),
(81, '2', '2', '3'),
(82, '3', '2', '36'),
(83, '7', '23', '36'),
(84, '4', '19', '36'),
(85, '6', '3', '36'),
(86, '9', '39', '36'),
(87, '2', '2', '6'),
(88, '3', '2', '41'),
(89, '7', '22', '41'),
(90, '4', '16', '41'),
(91, '6', '3', '41'),
(92, '9', '39', '41'),
(102, '3', '10', '42'),
(103, '7', '26', '42'),
(104, '4', '20', '42'),
(105, '6', '31', '42'),
(106, '9', '39', '42'),
(107, '2', '8', '42');

-- --------------------------------------------------------

--
-- Table structure for table `relatives`
--

CREATE TABLE `relatives` (
  `id` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL,
  `flow` varchar(64) default NULL,
  `familyName` varchar(50) NOT NULL,
  `type` varchar(64) NOT NULL,
  `address` varchar(64) default NULL,
  `phone` varchar(64) default NULL,
  `comments` mediumtext,
  `work` varchar(128) default NULL,
  PRIMARY KEY  (`id`),
  KEY `familyName` (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `relatives`
--

INSERT INTO `relatives` (`id`, `pid`, `flow`, `familyName`, `type`, `address`, `phone`, `comments`, `work`) VALUES
(1, 1, 'מסורתיים', 'מוזליביץ', 'אח', 'מנחת יצחק', '026865656', '', 'בעלי מכולת'),
(2, 2, 'חרדים', 'מוזליביץ', 'אחות', NULL, NULL, NULL, NULL),
(3, 16, 'מסורתיים', 'צברי', 'אח', '', '', '', ''),
(4, 36, 'חסידי', 'גולדברט', 'בת', 'גרינברג 12', '077-4007929', '', 'אברך');

-- --------------------------------------------------------

--
-- Table structure for table `search`
--

CREATE TABLE `search` (
  `pid` int(10) unsigned NOT NULL,
  `term` text NOT NULL,
  `name` varchar(250) NOT NULL,
  `age` int(10) unsigned NOT NULL,
  `gender` enum('male','female') NOT NULL,
  PRIMARY KEY  USING BTREE (`pid`),
  FULLTEXT KEY `text` (`term`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search`
--

INSERT INTO `search` (`pid`, `term`, `name`, `age`, `gender`) VALUES
(43, '   05267866  ', 'רבקה צ\\''ולפייב', 1983, 'female'),
(6, '   026731136  מנהלת לשכה', 'דבורה שטוק', 1993, 'female'),
(39, '   0775002461  ', 'יעל פרץ', 1977, 'female'),
(36, '   026432656  ', 'שמואל ראובני', 1977, 'male'),
(37, '   06554545  ', 'ענת וטורי', 1977, 'female'),
(38, '   025860989  ', 'תהילה לונצר', 1977, 'female'),
(40, '   0775002461  ', 'יעל פרץ', 1977, 'female'),
(42, '   052798963  איש שיווק', 'מיטרני רן', 1980, 'male'),
(41, '  ירושלים 026731136  תלמיד בחדר', 'דן שטוק', 2004, 'male'),
(19, '   026731136  ', 'שמעון רחמנוביץ', 1977, 'male'),
(17, ' אשכנזי    מתכנת', 'משה בנדר', 1981, 'male'),
(15, '665464 ליטאית   054698989 תלמידת סמינר', 'שמחה רבינוביץ', 1993, 'female'),
(4, '     מתכנת', 'סדן אהד', 1977, 'male'),
(3, '     ', 'אברהמי ברוך', 1977, 'male'),
(5, '     מנהלת לשכה', 'דבורה שטוק', 1977, 'female'),
(8, '     ', 'אלישבע שטוק', 1977, 'female'),
(7, ' גור    תלמידת גן', 'שירה שטוק', 1977, 'female'),
(10, '     ', 'בוסקילה1 שמעון', 1977, 'female'),
(9, '     ', 'שרביט יוסי', 1977, 'male'),
(12, '4645     ', 'לוי שרה', 1977, 'female'),
(11, '   0569565989  ', 'מזרחי יהושע', 1977, 'male'),
(13, '65998989 עיראקי ירושלים 026731136 0527122336 מצחצח נעליים', 'משולם זושא מוצאפי', 1977, 'male'),
(14, ' מרוקאי  026731136 0527122335 תלמיד ישיבה', 'ראובן מועלם', 1969, 'male'),
(16, ' אשכנזיה תל -אביב   מעצבת פנים', 'מיכל כץ', 1977, 'female'),
(18, ' יד עזרה ירושלים   נציגת שרות בחברת פלאפון', 'תהילה גוזלאנד', 1992, 'female'),
(20, '7787979  רמת גן 026731136  מנהל פרוייקטים', 'שמעון בניסטי', 1979, 'male'),
(35, '7987854  ירושלים 0267310326 050656566 מנהלת פרוייקטים', 'מעין ששון', 1979, 'female'),
(1, '457867897654 יד עזרה ירושלים 026731136 0527122336 מתכנת', 'אהד סדן-שטוק', 1978, 'male');

-- --------------------------------------------------------

--
-- Table structure for table `search_queries`
--

CREATE TABLE `search_queries` (
  `pid` int(10) unsigned NOT NULL,
  `data` longtext NOT NULL,
  `last` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_queries`
--

INSERT INTO `search_queries` (`pid`, `data`, `last`) VALUES
(1, '', '2011-05-13 03:06:04'),
(2, 'a', '2011-05-13 03:06:21'),
(6, 'a:9:{s:13:"search_gender";s:6:"female";s:4:"type";s:6:"search";s:2:"id";s:1:"6";s:7:"general";s:0:"";s:8:"age_from";s:1:"0";s:6:"age_to";s:2:"20";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:5:"def_3";s:1:"3";}', '2011-09-05 19:15:03'),
(10, 'a:11:{s:13:"search_gender";s:6:"male";s:10:"search_pid";s:2:"12";s:7:"general";s:7:"אהד סדן";s:8:"age_from";s:0:"";s:6:"age_to";s:0:"";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:6:"def_23";s:2:"23";s:6:"def_25";s:2:"25";s:4:"user";s:1:"3";s', '2011-05-13 03:01:25'),
(12, 'a:9:{s:13:"search_gender";s:6:"female";s:10:"search_pid";s:2:"12";s:7:"general";s:0:"";s:8:"age_from";s:0:"";s:6:"age_to";s:0:"";s:9:"relatives";s:0:"";s:12:"institutions";s:9:"שערי משפט";s:4:"user";s:1:"3";s:5:"token";s:32:"ef1e0121d2b6430c5c863f', '2011-05-13 12:14:22'),
(13, 'a:11:{s:13:"search_gender";s:4:"male";s:10:"search_pid";s:2:"13";s:7:"general";s:10:"דבורה שטוק";s:8:"age_from";s:0:"";s:6:"age_to";s:0:"";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:6:"def_22";s:2:"22";s:6:"def_25";s:2:"25";s:4:"user";s:', '0000-00-00 00:00:00'),
(14, 'a:11:{s:13:"search_gender";s:6:"male";s:10:"search_pid";s:2:"12";s:7:"general";s:7:"אהד סדן";s:8:"age_from";s:0:"";s:6:"age_to";s:0:"";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:6:"def_23";s:2:"23";s:6:"def_25";s:2:"25";s:4:"user";s:1:"3";s', '0000-00-00 00:00:00'),
(15, 'a:8:{s:13:"search_gender";s:6:"female";s:4:"type";s:6:"search";s:2:"id";s:2:"15";s:7:"general";s:0:"";s:8:"age_from";s:2:"17";s:6:"age_to";s:2:"25";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";}', '2011-08-01 00:00:26'),
(16, 'a:10:{s:2:"id";s:2:"16";s:13:"search_gender";s:6:"female";s:4:"type";s:6:"search";s:7:"general";s:6:"עיראקי";s:8:"age_from";s:2:"10";s:6:"age_to";s:2:"60";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:5:"def_1";s:1:"1";s:5:"def_5";s:1:"5";}', '2011-08-24 23:41:26'),
(17, 'a:8:{s:2:"id";s:2:"17";s:13:"search_gender";s:4:"male";s:4:"type";s:6:"search";s:7:"general";s:0:"";s:8:"age_from";s:2:"10";s:6:"age_to";s:2:"60";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";}', '2011-08-23 21:02:51'),
(18, 'a:9:{s:13:"search_gender";s:6:"female";s:4:"type";s:6:"search";s:2:"id";s:2:"18";s:7:"general";s:0:"";s:8:"age_from";s:2:"10";s:6:"age_to";s:2:"50";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:5:"def_1";s:1:"1";}', '2011-07-29 03:35:38'),
(19, 'a:9:{s:13:"search_gender";s:4:"male";s:4:"type";s:6:"search";s:2:"id";s:2:"19";s:7:"general";s:0:"";s:8:"age_from";s:2:"10";s:6:"age_to";s:2:"60";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:5:"def_1";s:1:"1";}', '2011-09-05 19:18:55'),
(20, 'a:8:{s:13:"search_gender";s:4:"male";s:4:"type";s:6:"search";s:2:"id";s:2:"20";s:7:"general";s:0:"";s:8:"age_from";s:2:"10";s:6:"age_to";s:2:"60";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";}', '2011-08-25 22:36:04'),
(35, 'a:9:{s:13:"search_gender";s:6:"female";s:4:"type";s:6:"search";s:2:"id";s:2:"35";s:7:"general";s:0:"";s:8:"age_from";s:2:"20";s:6:"age_to";s:2:"60";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:5:"def_1";s:1:"1";}', '2011-09-05 23:24:35'),
(38, 'a:10:{s:13:"search_gender";s:6:"female";s:4:"type";s:6:"search";s:2:"id";s:2:"38";s:7:"general";s:0:"";s:8:"age_from";s:0:"";s:6:"age_to";s:0:"";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:5:"def_1";s:1:"1";s:9:"PHPSESSID";s:32:"df6804db86d611c7cdc21fe0fab297a5";}', '2011-09-06 02:34:59'),
(43, 'a:10:{s:13:"search_gender";s:6:"female";s:4:"type";s:6:"search";s:2:"id";s:2:"43";s:7:"general";s:0:"";s:8:"age_from";s:2:"30";s:6:"age_to";s:2:"34";s:9:"relatives";s:0:"";s:12:"institutions";s:0:"";s:5:"def_5";s:1:"5";s:5:"def_9";s:1:"9";}', '2011-09-06 00:07:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `address` varchar(64) default NULL,
  `phone` varchar(45) default NULL,
  `cellphone` varchar(45) default NULL,
  `email` varchar(45) default NULL,
  `comments` mediumtext,
  `password` varchar(128) default NULL,
  `premmisions` int(10) unsigned default NULL,
  `updateDate` datetime NOT NULL,
  `insertDate` datetime NOT NULL,
  `nickName` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `address`, `phone`, `cellphone`, `email`, `comments`, `password`, `premmisions`, `updateDate`, `insertDate`, `nickName`) VALUES
(1, 'אהד', 'סדן', 'יוסלה רוזנבלט 1', '052-6731136', '0527122336', 'sadanoh@gmaIL.COM', '', '9d7534a27ccffbb85be52404f959165f', 256, '2010-10-27 09:25:44', '2010-10-27 09:25:44', 'אהד'),
(2, 'נחמן', 'קירשנבאום', 'רובין 20', '026731136', '0527122336', 'nachman@gmail.com', '', 'e10adc3949ba59abbe56e057f20f883e', 256, '2010-11-03 09:07:29', '2010-11-03 09:07:29', 'נחמן'),
(3, 'מיכל', 'סדן שטוק', 'יוסלה רוזנבלט 1', '026731136', '0527122335', 'michsadan@gmail.com', '', 'e10adc3949ba59abbe56e057f20f883e', 128, '2011-05-10 21:50:12', '2011-05-10 21:50:12', 'מיכלי'),
(4, 'מנחם', 'רוזנבאום', 'דוהמי 5', '05265656', '2565656', 'rtojfidj@jlkj.com', '', 'e10adc3949ba59abbe56e057f20f883e', 256, '2011-09-05 19:34:35', '2011-09-05 19:34:35', 'מנחם');
